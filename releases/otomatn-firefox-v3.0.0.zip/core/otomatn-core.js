/**
 * Otomatn Core — موتور ویرایش و نیم‌فاصله‌گذاری متن فارسی
 * ------------------------------------------------------------------
 * ویراستار قاعده‌محور (rule-based) و بدون وابستگی؛ در مرورگر، Node.js و Service Worker یکسان کار می‌کند.
 *
 * @version 3.0.0
 * @author  Reza Nemati <https://reza-nemati.ir>
 * @license MIT
 *
 * API:
 *   Otomatn.refine(text, options?)  -> { text, changes, total, before, after }
 *   Otomatn.diff(before, after)     -> [{ type: 'eq'|'del'|'ins', text }]
 *   Otomatn.analyze(text)           -> { chars, words, sentences, paragraphs, readingSeconds, persianRatio }
 *   Otomatn.RULES / PRESETS / CATEGORIES / DEFAULT_OPTIONS
 */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Otomatn = api;
})(typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ================================================================
   * ثابت‌ها و کلاس‌های نویسه
   * ================================================================ */
  const ZWNJ = '‌';
  /** حروف فارسی/عربی (همراه با اعراب) */
  const L = '\\u0621-\\u063A\\u0641-\\u064A\\u067E\\u0686\\u0698\\u06A9\\u06AF\\u06CC\\u06C0\\u064B-\\u0652';
  const PERSIAN_LETTER = new RegExp(`[${L}]`);
  const NON_JOINERS = new Set([...'آادذرزژوؤأإ']);
  const B_START = `(?<![${L}\\u200c])`; // آغاز واژه
  const B_END = `(?![${L}\\u200c])`; // پایان واژه
  const PUNCT = '.،؛:!؟?…,;';

  /** آیا میان حرف پایانی `word` و حرف بعدی باید نیم‌فاصله گذاشت؟ */
  const joinerFor = (word) => (word && NON_JOINERS.has(word[word.length - 1]) ? '' : ZWNJ);

  /** لیست‌ها را از قالب «الف|ب» به رشتهٔ دارای نیم‌فاصله تبدیل می‌کند. */
  const zw = (s) => s.replace(/\|/g, ZWNJ);
  const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  /* ================================================================
   * داده‌ها (واژه‌نامه‌ها)
   * ================================================================ */
  const PRESENT_STEMS = [
    'کن', 'شو', 'رو', 'آ', 'گو', 'دان', 'توان', 'خواه', 'خور', 'بین', 'گیر', 'دار', 'ده', 'بر', 'ساز', 'کش', 'گذار',
    'گذر', 'فرست', 'گرد', 'باش', 'نویس', 'خوان', 'پرس', 'پرداز', 'پذیر', 'شناس', 'فهم', 'یاب', 'مان', 'رس', 'ریز', 'نوش',
    'زن', 'بند', 'بخش', 'نشین', 'نشان', 'ایست', 'شمار', 'جو', 'پز', 'دو', 'فروش', 'خر', 'خند', 'گری', 'کار', 'کوش',
    'کوب', 'سپار', 'خواب', 'آور', 'افزا', 'نما', 'فرما', 'شنو', 'میر', 'افت', 'پوش', 'دوز', 'باف', 'چین', 'کاه', 'آموز',
    'پیوند', 'انجام', 'ترس', 'پندار', 'چرخ', 'افروز', 'ستا', 'گشا', 'باید', 'گوی', 'نگر', 'نگار', 'انداز', 'سوز', 'ران',
    'رسان', 'کِش', 'ورز', 'سنج', 'گزین', 'گزار', 'پرور', 'آمیز', 'آفرین', 'افرین', 'دهد', 'ماند', 'تاز', 'تاب', 'بخشا',
    'یار', 'خیز', 'جنگ', 'بال', 'فشار', 'فشان', 'کشان', 'شکن', 'شکف', 'گسل', 'گسار', 'نواز', 'نمای',
  ];
  const PAST_STEMS = [
    'رفت', 'آمد', 'گفت', 'کرد', 'شد', 'بود', 'داشت', 'خورد', 'دید', 'گرفت', 'داد', 'ساخت', 'نوشت', 'خواند', 'خواست',
    'توانست', 'دانست', 'ماند', 'رسید', 'پرسید', 'فرستاد', 'کشید', 'زد', 'ریخت', 'افتاد', 'ایستاد', 'نشست', 'خوابید',
    'گذاشت', 'گذشت', 'شناخت', 'فهمید', 'یافت', 'بست', 'پذیرفت', 'پرداخت', 'شمرد', 'خرید', 'فروخت', 'خندید', 'گریست',
    'دوید', 'پخت', 'بخشید', 'برد', 'کاشت', 'شکست', 'چید', 'پوشید', 'سپرد', 'گشت', 'گردید', 'دوخت', 'افزود', 'کاست',
    'نمود', 'فرمود', 'ربود', 'آورد', 'آموخت', 'انداخت', 'ترسید', 'نامید', 'پیوست', 'انجامید', 'جست', 'جنگید', 'چرخید',
    'زیست', 'سوخت', 'شنید', 'کوشید', 'گزید', 'گشود', 'مرد', 'نشاند', 'رساند', 'رویید', 'افروخت', 'بافت', 'ساخت',
    'ریزید', 'نوشید', 'دوشید', 'ستود', 'سرود', 'آفرید', 'آراست', 'پراند', 'تافت', 'تاخت', 'رقصید', 'پرید', 'لرزید',
  ];
  const VERB_REST_RE = new RegExp(
    '^(?:' +
      `(?:${PRESENT_STEMS.join('|')})ی?(?:م|ی|د|یم|ید|ند)` +
      '|' +
      `(?:${PAST_STEMS.join('|')})(?:م|ی|یم|ید|ند)?` +
      '|توان|بایست|باید' +
      ')$',
  );
  /** واژه‌هایی که با «می» شروع می‌شوند و فعل نیستند (برای حالت چسبیده). */
  const MI_NOT_VERB = new Set(['میدانی']);
  const MI_VERB_PREFIXES = '(?:بر|در|فرو|فرا|باز|وا|ور)?';

  const COMPOUND_WORDS = (
    'نیم|فاصله,پس|زمینه,پیش|فرض,پیش|نمایش,پیش|نیاز,پیش|نویس,نرم|افزار,سخت|افزار,اطلاع|رسانی,اطلاع|رسان,برنامه|نویسی,' +
    'برنامه|ریزی,برنامه|نویس,دانش|آموز,دست|نویس,دست|آورد,همه|چیز,هیچ|کس,هیچ|کدام,هیچ|وقت,هیچ|جا,هیچ|گاه,هیچ|چیز,' +
    'هیچ|یک,همین|طور,این|طور,آن|طور,این|جور,آن|جور,این|گونه,آن|گونه,علی|رغم,وب|سایت,وب|سرویس,وب|گاه,ارائه|دهنده,' +
    'ارائه|دهندگان,کاربر|پسند,کاربر|محور,مشتری|مدار,مشتری|محور,جست|وجو,گفت|وگو,پرس|وجو,رفت|وآمد,نقطه|گذاری,' +
    'فاصله|گذاری,علامت|گذاری,نام|گذاری,سرمایه|گذاری,سرمایه|گذار,قیمت|گذاری,هدف|گذاری,ارزش|گذاری,قانون|گذاری,' +
    'سیاست|گذاری,سیاست|گذار,رده|بندی,دسته|بندی,طبقه|بندی,جمع|بندی,زمان|بندی,بسته|بندی,نمره|دهی,امتیاز|دهی,' +
    'پاسخ|گویی,پاسخ|گو,نظر|سنجی,افکار|سنجی,آمار|گیری,تصمیم|گیری,تصمیم|گیرنده,نتیجه|گیری,اندازه|گیری,نمونه|گیری,' +
    'نمونه|برداری,بهره|برداری,بهره|وری,بهره|مند,بهره|گیری,نسخه|برداری,عکس|برداری,فیلم|برداری,پشتیبان|گیری,' +
    'خوش|آمد,خوش|آمدید,خوش|آمدی,خوش|نویسی,خوش|بین,بد|بین,ان|شاءالله,ما|شاءالله,' +
    '~به|روز,~به|روزرسانی,~به|روزرسان,~به|کارگیری,~به|سزا,~به|آفرین,~به|گزینی,~به|سازی,' +
    'بی|نظیر,بی|نهایت,بی|توجه,بی|تفاوت,بی|دلیل,بی|ادب,بی|اعتبار,بی|خبر,بی|رحم,بی|شک,بی|پایان,بی|سواد,بی|خانمان,' +
    'بی|فایده,بی|معنی,بی|حوصله,بی|انتها,بی|وفا,بی|تجربه,بی|ثبات,بی|هدف,بی|کفایت,بی|امنیت,بی|نیاز,بی|انصاف,' +
    'بی|اهمیت,بی|طرف,بی|تردید,بی|تکلف,بی|صدا,بی|رنگ,بی|نام,بی|هویت,بی|ارزش,بی|بدیل,بی|وقفه,بی|عاطفه,بی|مانند,' +
    'بی|نقص,بی|سابقه,بی|ربط,بی|احترامی,بی|مسئولیت,بی|دقتی,بی|نظمی,بی|عدالتی,بی|توجهی,بی|خوابی,بی|پروا,بی|گناه'
  )
    .split(',')
    .map((entry) => {
      const spacedOnly = entry.startsWith('~');
      const canonical = zw(spacedOnly ? entry.slice(1) : entry);
      const parts = (spacedOnly ? entry.slice(1) : entry).split('|');
      return { canonical, parts, spacedOnly };
    });

  /** [اشتباه, صحیح] — فقط واژهٔ کامل جایگزین می‌شود. */
  const SPELLING = [
    ['بخاطر', 'به خاطر'], ['بدلیل', 'به دلیل'], ['بنظر', 'به نظر'], ['بطور', 'به طور'], ['بعلت', 'به علت'],
    ['بعنوان', 'به عنوان'], ['بمنظور', 'به منظور'], ['بجای', 'به جای'], ['بجز', 'به جز'], ['بسوی', 'به سوی'],
    ['بنام', 'به نام'], ['علیرغم', 'علی‌رغم'], ['درصورتیکه', 'در صورتی که'], ['درصورتی‌که', 'در صورتی که'],
    ['درحالیکه', 'در حالی که'], ['درحالی‌که', 'در حالی که'], ['درضمن', 'در ضمن'], ['درصورت', 'در صورت'],
    ['درواقع', 'در واقع'], ['ازاین', 'از این'], ['ازآن', 'از آن'], ['ازجمله', 'از جمله'], ['ازطریق', 'از طریق'],
    ['ازبین', 'از بین'], ['بااین', 'با این'], ['بااینکه', 'با این‌که'], ['باوجود', 'با وجود'],
    ['باوجودیکه', 'با وجود این‌که'], ['تاحدی', 'تا حدی'], ['تابحال', 'تا به حال'], ['تاحالا', 'تا حالا'],
    ['یکسری', 'یک سری'], ['یکبار', 'یک بار'], ['انشاالله', 'ان‌شاءالله'], ['انشاءالله', 'ان‌شاءالله'],
    ['انشالله', 'ان‌شاءالله'], ['ماشالله', 'ماشاءالله'], ['ماشاالله', 'ماشاءالله'], ['ایشالا', 'ان‌شاءالله'],
    ['مساله', 'مسئله'], ['مسئوليت', 'مسئولیت'], ['مسوولیت', 'مسئولیت'], ['مسول', 'مسئول'], ['مسوول', 'مسئول'],
    ['رییس', 'رئیس'], ['هیات', 'هیئت'], ['متاسفانه', 'متأسفانه'], ['متاسف', 'متأسف'], ['تاسف', 'تأسف'],
    ['مولف', 'مؤلف'], ['مومن', 'مؤمن'], ['اظافه', 'اضافه'], ['اظافی', 'اضافی'], ['بلاخره', 'بالاخره'],
    ['واقعن', 'واقعاً'], ['مثلن', 'مثلاً'], ['اصلن', 'اصلاً'], ['حتمن', 'حتماً'], ['قطعن', 'قطعاً'],
    ['اتفاقن', 'اتفاقاً'], ['فعلن', 'فعلاً'], ['همچینین', 'همچنین'], ['همچنان‌که', 'همچنان که'],
  ];

  /** قیدهای عربی که تنوین می‌گیرند */
  const TANVIN_WORDS = (
    'مثلا اصلا حتما قطعا ضمنا واقعا اتفاقا عموما معمولا کاملا مخصوصا احتمالا ظاهرا لطفا فعلا اساسا دقیقا تقریبا عمدا ' +
    'قبلا بعدا اولا ثانیا ثالثا عملا نسبتا کلا رسما غالبا نهایتا صرفا مجددا مستقیما سریعا عینا حقیقتا اخیرا اجمالا ' +
    'طبعا لزوما تماما فورا احیانا دائما اصولا اکثرا مطمئنا صریحا شخصا شدیدا عادتا علنا قاعدتا خصوصا اجبارا ناچارا ' +
    'کاملا نوعا اصولا جزئا کلیتا مجموعا اساسا مشخصا ابتدائا انصافا اتفاقا'
  ).split(/\s+/);

  /** ترجیح املای رسمی در مقابل گفتاری (پیش‌فرض خاموش) */
  const FORMAL = [
    ['می|خوام', 'می|خواهم'], ['می|خوای', 'می|خواهی'], ['می|خواد', 'می|خواهد'], ['می|خوان', 'می|خواهند'],
    ['نمی|خوام', 'نمی|خواهم'], ['نمی|خوای', 'نمی|خواهی'], ['نمی|خواد', 'نمی|خواهد'],
    ['می|دونم', 'می|دانم'], ['می|دونی', 'می|دانی'], ['می|دونه', 'می|داند'], ['نمی|دونم', 'نمی|دانم'],
    ['نمی|دونی', 'نمی|دانی'], ['می|تونم', 'می|توانم'], ['می|تونی', 'می|توانی'], ['می|تونه', 'می|تواند'],
    ['می|تونیم', 'می|توانیم'], ['نمی|تونم', 'نمی|توانم'], ['نمی|تونی', 'نمی|توانی'], ['نمی|تونه', 'نمی|تواند'],
    ['می|شه', 'می|شود'], ['میشه', 'می|شود'], ['نمی|شه', 'نمی|شود'], ['نمیشه', 'نمی|شود'], ['می|رم', 'می|روم'],
    ['می|ری', 'می|روی'], ['می|ره', 'می|رود'], ['می|گم', 'می|گویم'], ['می|گی', 'می|گویی'], ['می|گه', 'می|گوید'],
    ['می|گن', 'می|گویند'], ['می|کنه', 'می|کند'], ['می|کنن', 'می|کنند'], ['نمی|کنه', 'نمی|کند'],
    ['می|دم', 'می|دهم'], ['می|ده', 'می|دهد'], ['می|خوره', 'می|خورد'], ['بریم', 'برویم'], ['برم', 'بروم'],
    ['چطور', 'چگونه'], ['چطوری', 'چگونه'], ['اینجوری', 'این|گونه'], ['اونجوری', 'آن|گونه'], ['اونجا', 'آنجا'],
    ['اون', 'آن'], ['اونا', 'آن|ها'], ['اینا', 'این|ها'], ['اونو', 'آن را'], ['اینو', 'این را'], ['ایشون', 'ایشان'],
    ['دیگه', 'دیگر'], ['واسه', 'برای'], ['برا', 'برای'], ['همش', 'همه|اش'], ['همه|ش', 'همه|اش'], ['یه', 'یک'],
    ['یکم', 'کمی'], ['خونه', 'خانه'], ['درسته', 'درست است'], ['آره', 'بله'], ['الان', 'اکنون'], ['هیچی', 'هیچ'],
    ['بعدش', 'بعد از آن'], ['خیلی‌خیلی', 'بسیار'], ['نیستش', 'نیست'], ['چیه', 'چیست'], ['کیه', 'کیست'],
    ['کجاست', 'کجاست'], ['اینه', 'این است'], ['اونه', 'آن است'],
  ].filter(([a, b]) => a !== b);

  const DUP_WORDS = ['و', 'که', 'در', 'از', 'را', 'با', 'برای', 'این'];

  /* ================================================================
   * ابزارهای داخلی
   * ================================================================ */

  /**
   * بستر اجرا: ثبت تغییرات هر قانون به همراه نمونه (با بافت اطراف).
   * @param {Record<string, any>} ruleMap
   */
  function createRecorder(ruleMap) {
    const stats = new Map();
    const record = (id, text, offset, matched, replaced) => {
      let s = stats.get(id);
      if (!s) stats.set(id, (s = { count: 0, samples: [] }));
      s.count++;
      if (s.samples.length < 6) {
        let a = Math.max(0, offset - 14);
        let b = Math.min(text.length, offset + matched.length + 14);
        const left = text.slice(a, offset);
        const right = text.slice(offset + matched.length, b);
        const trim = (s2, fromEnd) => {
          const m = fromEnd ? s2.match(/^[\s\S]*\s/) : s2.match(/\s/);
          if (!m) return s2;
          return fromEnd ? s2.slice(m[0].length) : s2.slice(0, m.index);
        };
        const l = a > 0 ? trim(left, true) : left;
        const r = b < text.length ? trim(right, false) : right;
        const sample = { from: l + matched + r, to: l + replaced + r };
        if (!s.samples.some((x) => x.from === sample.from)) s.samples.push(sample);
      }
    };
    /** معادل String.replace ولی با ثبت تغییر. replacer باید تابع باشد. */
    const sub = (id, text, re, replacer) =>
      text.replace(re, (...args) => {
        const matched = args[0];
        const out = replacer(...args);
        if (out !== matched) {
          const offsetIndex = args.findIndex((a, i) => i > 0 && typeof a === 'number');
          record(id, args[offsetIndex + 1], args[offsetIndex], matched, out);
        }
        return out;
      });
    return { sub, stats, ruleMap };
  }

  const stripSep = (s) => s.replace(/[ ‌]/g, '');
  const hasPersian = (s) => PERSIAN_LETTER.test(s);

  /* ================================================================
   * قوانین (فراداده برای رابط کاربری)
   * ================================================================ */
  const CATEGORIES = [
    { id: 'halfspace', label: 'نیم‌فاصله', icon: '↔' },
    { id: 'punctuation', label: 'نشانه‌گذاری', icon: '،' },
    { id: 'normalize', label: 'یکسان‌سازی نویسه‌ها', icon: 'ی' },
    { id: 'typography', label: 'صفحه‌آرایی و فاصله', icon: '¶' },
    { id: 'numbers', label: 'اعداد', icon: '۱' },
    { id: 'spelling', label: 'املا و واژگان', icon: 'ا' },
  ];

  /** @type {Array<{id:string,category:string,label:string,hint:string,example:[string,string],default:boolean}>} */
  const RULES = [
    // نیم‌فاصله
    { id: 'verb-prefix', category: 'halfspace', label: 'پیشوند افعال «می / نمی»', hint: 'می شود، میرود', example: ['می رود، نمیخواهم', 'می‌رود، نمی‌خواهم'], default: true },
    { id: 'plural-suffix', category: 'halfspace', label: 'نشانهٔ جمع «ها / های / گان»', hint: 'کتاب ها، کننده گان', example: ['کتاب ها، کننده گان', 'کتاب‌ها، کنندگان'], default: true },
    { id: 'participle-suffix', category: 'halfspace', label: 'پسوندهای ام / ای / اند و «ی»', hint: 'رفته ام، خانه ی', example: ['رفته ام، خانه ای', 'رفته‌ام، خانه‌ای'], default: true },
    { id: 'comparative', category: 'halfspace', label: 'صفت تفضیلی «تر / ترین»', hint: 'بزرگ تر، زیباترین', example: ['بزرگ تر، ساده ترین', 'بزرگ‌تر، ساده‌ترین'], default: true },
    { id: 'compound-words', category: 'halfspace', label: 'واژه‌های مرکب و پیشوندی', hint: 'بی نظیر، هیچ کس، پس زمینه', example: ['بی نظیر، پس زمینه', 'بی‌نظیر، پس‌زمینه'], default: true },
    { id: 'zwnj-cleanup', category: 'halfspace', label: 'پاک‌سازی نیم‌فاصلهٔ اضافی', hint: 'نیم‌فاصلهٔ تکراری یا کنار فاصله', example: ['کلمه‌‌ ‌بعد', 'کلمه بعد'], default: true },
    // نشانه‌گذاری
    { id: 'punct-language', category: 'punctuation', label: 'تبدیل نشانه‌های لاتین به فارسی', hint: ', ; ? ← ، ؛ ؟', example: ['چطوری?, خوبم;', 'چطوری؟، خوبم؛'], default: true },
    { id: 'punct-spacing', category: 'punctuation', label: 'فاصله‌گذاری قبل و بعد نشانه‌ها', hint: 'سلام ،خوبی؟', example: ['سلام ،خوبی ؟خوبم.ممنون', 'سلام، خوبی؟ خوبم. ممنون'], default: true },
    { id: 'punct-repeat', category: 'punctuation', label: 'نشانه‌های تکراری', hint: '!!! ؟؟؟ ،،', example: ['عالی!!! واقعا؟؟؟', 'عالی! واقعا؟'], default: true },
    { id: 'ellipsis', category: 'punctuation', label: 'سه‌نقطه (…)', hint: '... ← …', example: ['ببین...', 'ببین…'], default: true },
    { id: 'quotes', category: 'punctuation', label: 'گیومهٔ فارسی «»', hint: '"متن" ← «متن»', example: ['او گفت "سلام"', 'او گفت «سلام»'], default: true },
    { id: 'brackets', category: 'punctuation', label: 'فاصله در پرانتز و گیومه', hint: '( متن ) ← (متن)', example: ['متن ( نمونه ) است', 'متن (نمونه) است'], default: true },
    { id: 'dashes', category: 'punctuation', label: 'خط تیرهٔ بلند', hint: '-- ← —', example: ['او--کسی', 'او—کسی'], default: true },
    // یکسان‌سازی
    { id: 'unicode-forms', category: 'normalize', label: 'نویسه‌های نمایشی عربی (PDF و ورد)', hint: 'ﻣﺘﻦ ← متن', example: ['ﻣﺘﻦ ﻓﺎﺭﺳﯽ', 'متن فارسی'], default: true },
    { id: 'arabic-letters', category: 'normalize', label: 'ي ك ى ← ی ک ی', hint: 'حروف عربی به فارسی', example: ['كتاب علي', 'کتاب علی'], default: true },
    { id: 'invisible-chars', category: 'normalize', label: 'نویسه‌های نامرئی و کشیده', hint: 'کشیده، RLM، فاصلهٔ سخت', example: ['ســـلام', 'سلام'], default: true },
    { id: 'elongation', category: 'normalize', label: 'حروف کشیده‌شده', hint: 'سلاااام ← سلام', example: ['سلاااام عاااالی', 'سلام عالی'], default: true },
    { id: 'diacritics', category: 'normalize', label: 'حذف اعراب (فتحه، کسره، ...)', hint: 'مناسب متن‌های غیرقرآنی', example: ['مَتنِ', 'متن'], default: false },
    // صفحه‌آرایی
    { id: 'spaces', category: 'typography', label: 'فاصله‌های اضافی', hint: 'چند فاصله پشت‌سرهم، فاصلهٔ ابتدا/انتهای خط', example: ['یک   متن  ', 'یک متن'], default: true },
    { id: 'blank-lines', category: 'typography', label: 'خط‌های خالی اضافی', hint: 'بیش از یک خط خالی', example: ['الف\n\n\n\nب', 'الف\n\nب'], default: true },
    { id: 'script-spacing', category: 'typography', label: 'فاصله بین فارسی، لاتین و عدد', hint: 'سیستمWindows ← سیستم Windows', example: ['نسخهWindows11', 'نسخه Windows 11'], default: true },
    { id: 'join-lines', category: 'typography', label: 'اتصال سطرهای شکسته (متن کپی‌شده از PDF)', hint: 'سطرهای ناتمام را به هم می‌چسباند', example: ['این جمله\nادامه دارد.', 'این جمله ادامه دارد.'], default: false },
    // اعداد
    { id: 'digits', category: 'numbers', label: 'یکدست‌سازی ارقام', hint: '123 ← ۱۲۳', example: ['۱۲۳ و 456', '۱۲۳ و ۴۵۶'], default: true },
    { id: 'number-format', category: 'numbers', label: 'جداکنندهٔ هزارگان، اعشار و درصد', hint: '1,000 ← ۱٬۰۰۰ ، 50% ← ۵۰٪', example: ['50 %، 1,500', '۵۰٪، ۱٬۵۰۰'], default: true },
    // املا
    { id: 'spelling', category: 'spelling', label: 'اشتباهات املایی رایج', hint: 'بخاطر ← به خاطر، بطور ← به طور', example: ['بخاطر اینکه', 'به خاطر اینکه'], default: true },
    { id: 'tanvin', category: 'spelling', label: 'تنوین قیدها', hint: 'مثلا ← مثلاً، حتما ← حتماً', example: ['مثلا حتما', 'مثلاً حتماً'], default: true },
    { id: 'duplicate-words', category: 'spelling', label: 'حذف واژهٔ تکراری', hint: 'که که ← که', example: ['این این متن', 'این متن'], default: true },
    { id: 'formalize', category: 'spelling', label: 'رسمی‌سازی گفتاری', hint: 'میخوام ← می‌خواهم', example: ['نمیدونم چطوری', 'نمی‌دانم چگونه'], default: false },
  ];

  const ALL_ON = Object.fromEntries(RULES.map((r) => [r.id, r.default]));
  const only = (ids, extra = {}) => ({
    ...Object.fromEntries(RULES.map((r) => [r.id, false])),
    ...Object.fromEntries(ids.map((id) => [id, true])),
    ...extra,
  });

  const PRESETS = {
    minimal: {
      label: 'سبک',
      hint: 'فقط نیم‌فاصله و فاصله‌ها',
      rules: only(['verb-prefix', 'plural-suffix', 'participle-suffix', 'comparative', 'zwnj-cleanup', 'arabic-letters', 'spaces', 'punct-spacing']),
    },
    standard: { label: 'استاندارد', hint: 'پیشنهادی برای اغلب متن‌ها', rules: { ...ALL_ON } },
    full: {
      label: 'کامل',
      hint: 'همه چیز، حتی اتصال سطرها و حذف اعراب',
      rules: Object.fromEntries(RULES.map((r) => [r.id, r.id !== 'formalize'])),
    },
    formal: {
      label: 'رسمی',
      hint: 'استاندارد + تبدیل گفتاری به رسمی',
      rules: { ...ALL_ON, formalize: true },
    },
  };

  const DEFAULT_OPTIONS = Object.freeze({
    preset: 'standard',
    rules: null, // اگر مقدار داشته باشد بر پیش‌تنظیم اولویت دارد
    digits: 'fa', // 'fa' | 'en' | 'keep'
  });

  /* ================================================================
   * مراحل پردازش (به ترتیب اجرا)
   * ================================================================ */
  /** @type {Array<{rule: string, run: (text: string, ctx: any) => string}>} */
  const STEPS = [];
  const step = (rule, run) => STEPS.push({ rule, run });

  // --- یکسان‌سازی -------------------------------------------------
  step('unicode-forms', (t, { sub }) =>
    sub('unicode-forms', t, /[ﭐ-﷿ﹰ-﻿]+/g, (m) => m.normalize('NFKC')),
  );

  step('arabic-letters', (t, { sub }) =>
    sub('arabic-letters', t, /[يكىےەھہۃ]/g, (m) => ({ ي: 'ی', ك: 'ک', ى: 'ی', ے: 'ی', ە: 'ه', ھ: 'ه', ہ: 'ه', ۃ: 'ه' }[m])),
  );

  step('invisible-chars', (t, { sub }) => {
    t = sub('invisible-chars', t, /[  -   　]/g, () => ' ');
    t = sub('invisible-chars', t, /[​⁠﻿­‍ـ‎‏‪-‮⁦-⁩]/g, () => '');
    return t;
  });

  step('diacritics', (t, { sub }) => sub('diacritics', t, /[ً-ْٰۖ-ۭ]/g, () => ''));

  step('elongation', (t, { sub }) =>
    sub('elongation', t, new RegExp(`([${L.replace('\\u064B-\\u0652', '')}])\\1{2,}`, 'g'), (m, c) => c),
  );

  // فاصلهٔ افقی اضافی (پیش از قوانین نیم‌فاصله لازم است)
  step('spaces', (t, { sub }) => {
    t = sub('spaces', t, /[ \t\f\v]{2,}/g, () => ' ');
    t = sub('spaces', t, /\t/g, () => ' ');
    return t;
  });

  // --- املا و واژگان ----------------------------------------------
  step('formalize', (t, { sub }) => {
    for (const [from, to] of FORMAL) {
      const pattern = zw(from).split(ZWNJ).map(escapeRe).join('[ \\u200c]?');
      t = sub('formalize', t, new RegExp(`${B_START}${pattern}${B_END}`, 'g'), () => zw(to));
    }
    return t;
  });

  step('spelling', (t, { sub }) => {
    for (const [from, to] of SPELLING) {
      t = sub('spelling', t, new RegExp(`${B_START}${escapeRe(from)}${B_END}`, 'g'), () => to);
    }
    return t;
  });

  // --- نیم‌فاصله ----------------------------------------------------
  step('compound-words', (t, { sub }) => {
    for (const { canonical, parts, spacedOnly } of COMPOUND_WORDS) {
      const sep = spacedOnly ? '[ \\u200c]' : '[ \\u200c]?';
      const re = new RegExp(`${B_START}${parts.map(escapeRe).join(sep)}${B_END}`, 'g');
      t = sub('compound-words', t, re, () => canonical);
    }
    return t;
  });

  step('verb-prefix', (t, { sub }) => {
    const re = new RegExp(`${B_START}(${MI_VERB_PREFIXES}ن?می)([ \\u200c]?)([${L}]+)${B_END}`, 'g');
    return sub('verb-prefix', t, re, (m, prefix, sep, rest) => {
      if (!VERB_REST_RE.test(rest)) return m;
      if (sep === '' && MI_NOT_VERB.has(prefix + rest)) return m;
      return prefix + ZWNJ + rest;
    });
  });

  step('plural-suffix', (t, { sub }) => {
    const PLURAL_EXCEPT = new Set(['رها', 'اشتها', 'انتها', 'ابتها', 'بها', 'ابها', 'نها', 'مها', 'گیاها']);
    const SUF = '(ها(?:یی|ی|یم|یت|یش|یمان|یتان|یشان)?)';
    // «ها» جداشده با فاصله
    t = sub('plural-suffix', t, new RegExp(`${B_START}([${L}\\u200c]*[${L}]) ${SUF}${B_END}`, 'g'), (m, word, suf) => {
      if (word === 'ها' || word === 'ی') return m;
      return word + joinerFor(word) + suf;
    });
    // «ها» چسبیده
    t = sub('plural-suffix', t, new RegExp(`${B_START}([${L}]{2,}?)${SUF}${B_END}`, 'g'), (m, stem, suf) => {
      if (PLURAL_EXCEPT.has(stem + 'ها') || PLURAL_EXCEPT.has(m)) return m;
      return stem + joinerFor(stem) + suf;
    });
    // کننده گان ← کنندگان
    t = sub('plural-suffix', t, new RegExp(`${B_START}([${L}]*?[${L}])ه[ \\u200c]?گان${B_END}`, 'g'), (m, stem) => stem + 'گان');
    return t;
  });

  step('participle-suffix', (t, { sub }) => {
    t = sub('participle-suffix', t, new RegExp(`${B_START}([${L}]+ه) (ام|ای|ایم|اید|اند|ای|ی)${B_END}`, 'g'), (m, w, s) => w + ZWNJ + s);
    // گم شده ← گم‌شده، رها شده ← رها‌شده
    t = sub('participle-suffix', t, new RegExp(`${B_START}(گم|رها|غصب)[ \\u200c]?(شده|شدگان|شدگی)${B_END}`, 'g'), (m, a, s) => a + ZWNJ + s);
    return t;
  });

  step('comparative', (t, { sub }) => {
    const ADJ = [
      'بزرگ', 'کوچک', 'خوب', 'بد', 'زیبا', 'زود', 'دیر', 'مهم', 'ساده', 'سخت', 'آسان', 'سریع', 'بلند', 'کوتاه', 'قوی',
      'ضعیف', 'پایین', 'بالا', 'عمیق', 'دقیق', 'روشن', 'تاریک', 'سبک', 'سنگین', 'گرم', 'سرد', 'پیر', 'جوان', 'تازه',
      'قدیم', 'جدید', 'طولانی', 'کامل', 'مناسب', 'مفید', 'پیچیده', 'واضح', 'شیرین', 'تلخ', 'ارزان', 'گران', 'نزدیک',
      'دور', 'عالی', 'پرکار', 'مشهور', 'محکم', 'نرم', 'تمیز', 'سالم', 'ملایم', 'قشنگ', 'باهوش', 'خوشحال', 'مطمئن',
    ];
    t = sub('comparative', t, new RegExp(`${B_START}(${ADJ.join('|')})[ \\u200c]?(ترین|تر)${B_END}`, 'g'), (m, a, s) => a + joinerFor(a) + s);
    // کم/بیش/به بدون نیم‌فاصله نوشته می‌شوند
    t = sub('comparative', t, new RegExp(`${B_START}(بیش|کم|به)[ \\u200c](ترین|تر)${B_END}`, 'g'), (m, a, s) => a + s);
    return t;
  });

  // --- تنوین و تکرار ------------------------------------------------
  step('tanvin', (t, { sub }) =>
    sub('tanvin', t, new RegExp(`${B_START}(${[...new Set(TANVIN_WORDS)].join('|')})${B_END}`, 'g'), (m) => m + 'ً'),
  );

  step('duplicate-words', (t, { sub }) =>
    sub('duplicate-words', t, new RegExp(`${B_START}(${DUP_WORDS.join('|')})([ \\t]+)\\1${B_END}`, 'g'), (m, w) => w),
  );

  // --- نشانه‌گذاری ---------------------------------------------------
  step('script-spacing', (t, { sub }) => {
    const LAT = 'A-Za-z';
    // پسوند فارسی پس از واژهٔ لاتین ← نیم‌فاصله
    t = sub('script-spacing', t, new RegExp(`([${LAT}])(ها|های|هایی|ی|ام|ات|اش|ایم|اید|اند|ای)${B_END}`, 'g'), (m, a, s) => a + ZWNJ + s);
    t = sub('script-spacing', t, new RegExp(`([${L}])(?=[${LAT}])`, 'g'), (m, a) => a + ' ');
    t = sub('script-spacing', t, new RegExp(`([${LAT}])(?=[${L}])`, 'g'), (m, a) => a + ' ');
    t = sub('script-spacing', t, new RegExp(`([${L}])(?=[0-9۰-۹])`, 'g'), (m, a) => a + ' ');
    t = sub('script-spacing', t, new RegExp(`([0-9۰-۹])(?=[${L}])`, 'g'), (m, a) => a + ' ');
    return t;
  });

  step('punct-language', (t, { sub }) => {
    t = sub('punct-language', t, new RegExp(`(?<=[${L}\\u200c»)])([ \\t]*)\\?`, 'g'), () => '؟');
    t = sub('punct-language', t, new RegExp(`(?<=[${L}\\u200c»)؟!])([ \\t]*),`, 'g'), () => '،');
    t = sub('punct-language', t, new RegExp(`(?<=[${L}\\u200c»)])([ \\t]*);`, 'g'), () => '؛');
    return t;
  });

  step('punct-repeat', (t, { sub }) => {
    t = sub('punct-repeat', t, /!{2,}/g, () => '!');
    t = sub('punct-repeat', t, /؟{2,}|\?{2,}/g, (m) => m[0]);
    t = sub('punct-repeat', t, /،{2,}/g, () => '،');
    t = sub('punct-repeat', t, /؛{2,}/g, () => '؛');
    return t;
  });

  step('ellipsis', (t, { sub }) => {
    t = sub('ellipsis', t, /\.{3,}|…{2,}/g, () => '…');
    t = sub('ellipsis', t, /(?<=[…!؟?])\./g, () => '');
    return t;
  });

  step('quotes', (t, { sub }) => {
    t = sub('quotes', t, new RegExp(`"([^"\\n]*[${L}][^"\\n]*)"`, 'g'), (m, inner) => `«${inner.trim()}»`);
    t = sub('quotes', t, new RegExp(`[“„]([^”“\\n]*[${L}][^”“\\n]*)”`, 'g'), (m, inner) => `«${inner.trim()}»`);
    t = sub('quotes', t, new RegExp(`''([^'\\n]*[${L}][^'\\n]*)''`, 'g'), (m, inner) => `«${inner.trim()}»`);
    return t;
  });

  step('brackets', (t, { sub }) => {
    t = sub('brackets', t, /([(\[{«])[ \t]+/g, (m, o) => o);
    t = sub('brackets', t, /[ \t]+([)\]}»])/g, (m, c) => c);
    t = sub('brackets', t, new RegExp(`([${L}])(?=[(\\[«])`, 'g'), (m, a) => a + ' ');
    t = sub('brackets', t, new RegExp(`([)\\]»])(?=[${L}])`, 'g'), (m, c) => c + ' ');
    return t;
  });

  step('punct-spacing', (t, { sub }) => {
    const P = 'spacing';
    // حذف فاصله پیش از نشانه
    t = sub('punct-spacing', t, /[ \t]+(?=[،؛؟!…])/g, () => '');
    t = sub('punct-spacing', t, /[ \t]+(?=\.(?![\dA-Za-z.]))/g, () => '');
    t = sub('punct-spacing', t, /[ \t]+(?=:(?![ \t]*[\d۰-۹A-Za-z]))/g, () => '');
    // افزودن فاصله پس از نشانه
    t = sub('punct-spacing', t, new RegExp(`([،؛؟])(?=[^\\s${PUNCT}\\)\\]\\}»"”\\u200c])`, 'g'), (m, p) => p + ' ');
    t = sub('punct-spacing', t, new RegExp(`([.:!…])(?=[${L}«“(\\uE100-\\uE9FF])`, 'g'), (m, p) => p + ' ');
    void P;
    return t;
  });

  step('dashes', (t, { sub }) => sub('dashes', t, new RegExp(`(?<=[${L}])[ \\t]*--[ \\t]*(?=[${L}])`, 'g'), () => '—'));

  // --- اعداد ---------------------------------------------------------
  step('digits', (t, { sub, options }) => {
    if (options.digits === 'en') {
      return sub('digits', t, /[۰-۹٠-٩٫٬٪]/g, (m) => {
        if (m === '٫') return '.';
        if (m === '٬') return ',';
        if (m === '٪') return '%';
        return String(m.charCodeAt(0) - (m.charCodeAt(0) >= 0x06f0 ? 0x06f0 : 0x0660));
      });
    }
    if (options.digits !== 'fa') return t;
    t = sub('digits', t, /[٠-٩]/g, (m) => String.fromCharCode(m.charCodeAt(0) - 0x0660 + 0x06f0));
    return t.replace(/[^\n]+/g, (line) => {
      if (!hasPersian(line)) return line;
      return sub('digits', line, /([A-Za-z_@#\/\\][\w.\-@#\/\\:]*|\d+[A-Za-z_][\w.\-]*)|(\d+(?:[.,]\d+)*)/g, (m, latin, num) => {
        if (latin) return m;
        const out = num.replace(/\d/g, (d) => String.fromCharCode(d.charCodeAt(0) - 48 + 0x06f0));
        return out;
      });
    });
  });

  step('number-format', (t, { sub, options }) => {
    if (options.digits === 'en') {
      return sub('number-format', t, /(\d)[ \t]*٪/g, (m, d) => d + '%');
    }
    if (options.digits !== 'fa') return t;
    t = sub('number-format', t, /(?<=[۰-۹])(,)(?=[۰-۹]{3}(?![۰-۹]))/g, () => '٬');
    // اعشار: فقط وقتی عدد دقیقاً یک نقطه دارد (نسخه‌ها و IP دست نمی‌خورند)
    t = sub('number-format', t, /(?<![۰-۹.])([۰-۹]+)\.([۰-۹]+)(?![۰-۹]*\.[۰-۹])/g, (m, a, b) => a + '٫' + b);
    t = sub('number-format', t, /([۰-۹])[ \t]*%/g, (m, d) => d + '٪');
    return t;
  });

  // --- صفحه‌آرایی ----------------------------------------------------
  step('join-lines', (t, { sub }) => {
    const LIST = /^\s*(?:[-*•–]|[\d۰-۹]+[.)\-])\s/;
    return sub('join-lines', t, /([^\n])\n(?=[^\n])/g, (m, last, offset, str) => {
      const rest = str.slice(offset + 2, str.indexOf('\n', offset + 2) === -1 ? undefined : str.indexOf('\n', offset + 2));
      const lineStart = str.lastIndexOf('\n', offset) + 1;
      const line = str.slice(lineStart, offset + 1);
      if (/[.!؟?:؛…»)\]]$/.test(last) || LIST.test(rest) || LIST.test(line)) return m;
      return last + ' ';
    });
  });

  step('spaces', (t, { sub }) => {
    t = sub('spaces', t, /[ \t]+$/gm, () => '');
    t = sub('spaces', t, /^[ \t]+/gm, () => '');
    t = sub('spaces', t, /^\s+|\s+$/g, () => '');
    return t;
  });

  step('blank-lines', (t, { sub }) => {
    t = t.replace(/\r\n?/g, '\n');
    return sub('blank-lines', t, /\n{3,}/g, () => '\n\n');
  });

  // --- پاک‌سازی نهایی نیم‌فاصله -------------------------------------
  step('zwnj-cleanup', (t, { sub }) => {
    t = sub('zwnj-cleanup', t, /‌{2,}/g, () => ZWNJ);
    t = sub('zwnj-cleanup', t, /‌+(?=[ \t\n]|$)|(?<=^|[ \t\n])‌+/g, () => '');
    t = sub('zwnj-cleanup', t, /‌(?=[،؛؟!.:…»)\]}])/g, () => '');
    t = sub('zwnj-cleanup', t, /(?<=[(\[{«])‌/g, () => '');
    return t;
  });

  /* ================================================================
   * محافظت از بخش‌هایی که نباید دست بخورند (لینک، ایمیل، کد، ...)
   * ================================================================ */
  const PROTECT_RE = new RegExp(
    [
      '```[\\s\\S]*?```', // بلوک کد
      '`[^`\\n]+`', // کد درون‌خطی
      '(?:https?:\\/\\/|ftp:\\/\\/|www\\.)[^\\s<>"«»]*[^\\s<>"«».,،؛:!؟?)\\]]', // نشانی وب
      '[\\w.+-]+@[\\w-]+(?:\\.[\\w-]+)+', // ایمیل
      '(?<![\\w@])@[A-Za-z0-9_.]{2,}', // نام کاربری
      '[A-Za-z]:\\\\[^\\s"<>|]+', // مسیر ویندوز
      '(?<=\\s|^)(?:\\/[\\w.\\-]+){2,}\\/?', // مسیر یونیکسی
    ].join('|'),
    'g',
  );

  function mask(text) {
    const saved = [];
    const out = text.replace(PROTECT_RE, (m) => {
      if (saved.length >= 0x0800) return m;
      saved.push(m);
      return String.fromCharCode(0xe100 + saved.length - 1);
    });
    return { out, saved };
  }
  const unmask = (text, saved) => text.replace(/[-]/g, (c) => saved[c.charCodeAt(0) - 0xe100] ?? c);

  /* ================================================================
   * API عمومی
   * ================================================================ */
  function resolveRules(options) {
    const preset = PRESETS[options.preset] || PRESETS.standard;
    return { ...preset.rules, ...(options.rules || {}) };
  }

  /**
   * متن را ویرایش می‌کند.
   * @param {string} input
   * @param {{preset?: string, rules?: Record<string, boolean>|null, digits?: 'fa'|'en'|'keep'}} [opts]
   */
  function refine(input, opts = {}) {
    const options = { ...DEFAULT_OPTIONS, ...opts };
    const enabled = resolveRules(options);
    const source = String(input ?? '').replace(/\r\n?/g, '\n');
    const { out, saved } = mask(source);
    const recorder = createRecorder(enabled);
    const ctx = { sub: recorder.sub, options, enabled };

    let text = out;
    for (const s of STEPS) {
      if (enabled[s.rule]) text = s.run(text, ctx);
    }
    text = unmask(text, saved);

    const ruleIndex = new Map(RULES.map((r, i) => [r.id, i]));
    const changes = [...recorder.stats.entries()]
      .map(([id, s]) => {
        const rule = RULES[ruleIndex.get(id)];
        return { rule: id, category: rule.category, label: rule.label, count: s.count, samples: s.samples };
      })
      .sort((a, b) => ruleIndex.get(a.rule) - ruleIndex.get(b.rule));

    return {
      text,
      changes,
      total: changes.reduce((n, c) => n + c.count, 0),
      before: analyze(source),
      after: analyze(text),
    };
  }

  /** آمار متن */
  function analyze(text) {
    const t = String(text || '');
    const words = (t.match(/[\p{L}\p{N}\p{M}]+(?:‌[\p{L}\p{N}\p{M}]+)*/gu) || []).length;
    const letters = (t.match(new RegExp(`[${L}]`, 'g')) || []).length;
    const latin = (t.match(/[A-Za-z]/g) || []).length;
    return {
      chars: t.length,
      charsNoSpace: t.replace(/\s/g, '').length,
      words,
      sentences: (t.match(/[.!؟?…]+(?=\s|$)|\n+/g) || []).length || (words ? 1 : 0),
      paragraphs: t.trim() ? t.trim().split(/\n\s*\n/).length : 0,
      readingSeconds: Math.ceil(words / 3.3),
      persianRatio: letters + latin ? letters / (letters + latin) : 0,
    };
  }

  /**
   * تفاوت دو متن در سطح واژه (برای نمایش «قبل و بعد»).
   * @returns {Array<{type: 'eq'|'del'|'ins', text: string}>}
   */
  function diff(before, after) {
    if (before === after) return before ? [{ type: 'eq', text: before }] : [];
    const tokenize = (s) => s.match(/[\p{L}\p{N}\p{M}‌]+|\s+|[^\s]/gu) || [];
    const a = tokenize(before);
    const b = tokenize(after);

    let start = 0;
    while (start < a.length && start < b.length && a[start] === b[start]) start++;
    let endA = a.length;
    let endB = b.length;
    while (endA > start && endB > start && a[endA - 1] === b[endB - 1]) {
      endA--;
      endB--;
    }
    const mid = [];
    const A = a.slice(start, endA);
    const B = b.slice(start, endB);

    if (A.length * B.length > 4_000_000) {
      // متن بسیار بزرگ: خلاصهٔ ساده
      if (A.length) mid.push({ type: 'del', text: A.join('') });
      if (B.length) mid.push({ type: 'ins', text: B.join('') });
    } else {
      // LCS
      const n = A.length;
      const m = B.length;
      const dp = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
      for (let i = n - 1; i >= 0; i--)
        for (let j = m - 1; j >= 0; j--)
          dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
      let i = 0;
      let j = 0;
      while (i < n && j < m) {
        if (A[i] === B[j]) mid.push({ type: 'eq', text: A[i++] }), j++;
        else if (dp[i + 1][j] >= dp[i][j + 1]) mid.push({ type: 'del', text: A[i++] });
        else mid.push({ type: 'ins', text: B[j++] });
      }
      while (i < n) mid.push({ type: 'del', text: A[i++] });
      while (j < m) mid.push({ type: 'ins', text: B[j++] });
    }

    const ops = [];
    const push = (type, text) => {
      const last = ops[ops.length - 1];
      if (last && last.type === type) last.text += text;
      else ops.push({ type, text });
    };
    if (start) push('eq', a.slice(0, start).join(''));
    // هم‌گروه‌سازی: در هر تغییر پیوسته، ابتدا حذف‌ها و سپس درج‌ها
    let delBuf = '';
    let insBuf = '';
    const flush = () => {
      if (delBuf) push('del', delBuf);
      if (insBuf) push('ins', insBuf);
      delBuf = insBuf = '';
    };
    for (const op of mid) {
      if (op.type === 'eq') {
        flush();
        push('eq', op.text);
      } else if (op.type === 'del') delBuf += op.text;
      else insBuf += op.text;
    }
    flush();
    if (endA < a.length) push('eq', a.slice(endA).join(''));
    return ops;
  }

  return {
    version: '3.0.0',
    refine,
    diff,
    analyze,
    RULES,
    CATEGORIES,
    PRESETS,
    DEFAULT_OPTIONS,
    ZWNJ,
  };
});
